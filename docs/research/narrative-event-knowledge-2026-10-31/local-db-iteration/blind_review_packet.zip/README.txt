Blinded narrative preview rating packet

Each blind_target_id identifies two versions of the same matchup, as-of cutoff, and authorized evidence. Rate every blind_id in blind_ratings_template.csv from 1 (poor) to 5 (excellent) for relevance, factual accuracy, specificity, and readability. Use notes for unsupported or misleading claims.

Use only blind_comparison.jsonl, blind_evidence.jsonl, and the ratings template. Do not inspect generator-labeled research artifacts or ask for the ID-to-generator key until ratings are complete.
